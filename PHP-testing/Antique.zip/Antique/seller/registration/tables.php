<?php
$table="tbl_seller";
$target_path = "uploads/";
$title=" Seller details";
?>