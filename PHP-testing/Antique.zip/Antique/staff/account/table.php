<?php
$table="trascation";
$target_path = "uploads/";
$title="Account";
?>