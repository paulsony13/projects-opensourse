
<?php
$con = mysqli_connect("testdb.c9czu1qxnqra.ap-south-1.rds.amazonaws.com","admin","Paulsony1*","antique") or die(mysqli_error());

?>
