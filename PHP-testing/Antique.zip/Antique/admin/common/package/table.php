<?php
$table="package";
$target_path = "uploads/";
$title="package";
?>