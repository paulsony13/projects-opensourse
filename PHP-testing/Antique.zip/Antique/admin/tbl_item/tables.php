<?php
$table="tbl_item";
$target_path = "uploads/";
$title=" Item details";
?>