<?php
$table="invoice";
$target_path = "uploads/";
$title=" Order details";
?>