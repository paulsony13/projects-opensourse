<?php
$table="tbl_order_master";
$target_path = "uploads/";
$title=" Order details";
?>