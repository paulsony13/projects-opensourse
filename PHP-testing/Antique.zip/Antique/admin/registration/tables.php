<?php
$table="tbl_customer";
$target_path = "uploads/";
$title=" Customer details";
?>