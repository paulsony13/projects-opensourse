<?php
$table="tbl_feedback";
$target_path = "uploads/";
$title=" Order details";
?>