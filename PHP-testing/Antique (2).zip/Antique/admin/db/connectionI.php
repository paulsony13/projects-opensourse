<?php
//session_start();
date_default_timezone_set("Asia/Calcutta");

$con=mysqli_connect("testdb.c9czu1qxnqra.ap-south-1.rds.amazonaws.com","admin","Paulsony1*","antique");
?>