<?php
$table="tbl_userpreference";
$target_path = "uploads/";
$title="User Preference";
?>