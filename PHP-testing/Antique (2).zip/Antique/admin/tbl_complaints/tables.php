<?php
$table="tbl_complaint";
$target_path = "uploads/";
$title=" Order details";
?>