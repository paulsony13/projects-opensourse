<?php
$table="tbl_item";
$target_path = "../../admin/tbl_item/uploads/";
$title=" Item details";
?>